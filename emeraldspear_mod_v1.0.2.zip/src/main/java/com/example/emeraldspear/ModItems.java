package com.example.emeraldspear;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, EmeraldSpearMod.MODID);

    public static final RegistryObject<Item> EMERALD_SPEAR =
            ITEMS.register("emerald_spear", () -> new EmeraldSpearItem(new Item.Properties()));
}
