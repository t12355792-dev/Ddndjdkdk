package com.example.emeraldspear;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.enchantment.Enchantment;

public class ModEnchantments {

    /** Задан датапаком: data/emeraldspear/enchantment/lunge.json (макс. уровень 4). */
    public static final ResourceKey<Enchantment> LUNGE_KEY =
            ResourceKey.create(Registries.ENCHANTMENT,
                    ResourceLocation.fromNamespaceAndPath(EmeraldSpearMod.MODID, "lunge"));
}
