package com.example.emeraldspear;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(EmeraldSpearMod.MODID)
public class EmeraldSpearMod {
    public static final String MODID = "emeraldspear";

    public EmeraldSpearMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEnchantments.ENCHANTMENTS.register(bus);
        ModCreativeTabs.TABS.register(bus);
    }
}
