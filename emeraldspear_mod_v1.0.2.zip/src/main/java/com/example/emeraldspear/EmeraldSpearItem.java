package com.example.emeraldspear;

import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.*;

public class EmeraldSpearItem extends SwordItem {

    /** Характеристики копья: урон 6 (5 базовых + 1 бонус тира), прочность 512. */
    public static final Tier TIER = new Tier() {
        @Override public int getUses() { return 512; }
        @Override public float getSpeed() { return 6.5f; }
        @Override public float getAttackDamageBonus() { return 1.0f; }
        @Override public TagKey<Block> getIncorrectBlocksForDrops() { return BlockTags.INCORRECT_FOR_IRON_TOOL; }
        @Override public int getEnchantmentValue() { return 18; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.of(Items.EMERALD); }
    };

    public EmeraldSpearItem(Properties props) {
        super(TIER, props
                .attributes(createAttributes(TIER, 5, -2.8f))
                .attributes(spearAttributes()));
    }

    /** Дальность удара: +1.5 блока в основной руке. */
    private static AttributeModifiers spearAttributes() {
        return AttributeModifiers.builder()
                .add(Attributes.ENTITY_INTERACTION_RANGE,
                        new AttributeModifier(
                                ResourceLocation.fromNamespaceAndPath(EmeraldSpearMod.MODID, "spear_reach"),
                                1.5, AttributeModifier.Operation.ADD_VALUE),
                        EquipmentSlotGroup.MAINHAND)
                .build();
    }

    /** Бонус урона от "Выпада": +0.5 за уровень, при близкой цели бонус уменьшен. */
    @Override
    public float getAttackDamageBonus(Entity target, float base, DamageSource source) {
        int level = lungeLevel(target);
        if (level <= 0) return super.getAttackDamageBonus(target, base, source);
        double dist = source.getDirectEntity() != null
                ? source.getDirectEntity().position().distanceTo(target.position()) : 0.0;
        double falloff = Math.min(1.0, Math.max(0.4, dist / 3.0));
        return super.getAttackDamageBonus(target, base, source) + (float)(0.5 * level * falloff);
    }

    private int lungeLevel(Entity target) {
        if (target == null) return 0;
        Registry<Enchantment> reg = target.level().registryAccess()
                .lookupOrThrow(Registries.ENCHANTMENT);
        Holder.Reference<Enchantment> holder = reg.getHolderOrThrow(ModEnchantments.LUNGE_KEY);
        return target.getMainHandItem().getEnchantmentLevel(holder);
    }
}
