# Emerald Spear (Minecraft 26.3, Forge 66.1.3)

## Сборка
- Локально: `gradle build` (Gradle 9.2.1, JDK 21) — jar появится в `build/libs`.
- Через CI: пуш в main — GitHub Actions соберёт jar, артефакт будет на странице Actions.

## Текстура
Готовый спрайт уже лежит по пути
`src/main/resources/assets/emeraldspear/textures/item/emerald_spear.png`
(изумрудный наконечник, изумрудный набалдашник, деревянное древко, красная обмотка).

## Предмет
- Урон 6, скорость атаки 1.2, дальность +1.5 блока, прочность 512, ремонт изумрудом.
- Крафт: изумруд сверху + 2 палки столбиком.

## Зачарование "Выпад" (до 4 уровня)
- +0.75 блока дальности и +0.5 урона за уровень (урон плавно спадает при близкой цели).
- Накладывается на копьё и трезубец (тег `#emeraldspear:lunge_enchantable`).

## Возможные правки под свежие маппинги
- `lookupOrThrow` → в старых версиях `registryOrThrow`.
- `ResourceLocation.fromNamespaceAndPath` → `new ResourceLocation(MODID, "lunge")`.
- Определение зачарования полностью датапаковое (`data/emeraldspear/enchantment/lunge.json`), регистрация кодом не требуется.
